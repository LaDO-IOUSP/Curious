% cometarios 



load dados.mat



